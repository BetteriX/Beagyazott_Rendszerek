#!/usr/bin/env python3

from sense_hat import SenseHat
import time

sense = SenseHat()
state = 0
halted = False

w = (255, 255, 255)
r = (255, 0, 0)
g = (0, 255, 0)
y = (255, 255, 0)
n = (0, 0, 0)
# fmt: off
red = [
    n, n, n, r, r, n, n, n,
    n, n, n, r, r, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n
]

red_yellow = [
    n, n, n, r, r, n, n, n,
    n, n, n, r, r, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, y, y, n, n, n,
    n, n, n, y, y, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n
    ]

yellow = [
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, y, y, n, n, n,
    n, n, n, y, y, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n
]

green = [
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, n, n, n, n, n,
    n, n, n, g, g, n, n, n,
    n, n, n, g, g, n, n, n
]
# fmt: on

lights = {0: red, 1: red_yellow, 2: yellow, 3: green}


def states(duration):
    sense.set_pixels(lights[state])
    time.sleep(duration)
    sense.clear()


def out_of_order_state():
    sense.set_pixels(yellow)
    time.sleep(0.5)
    sense.clear()
    time.sleep(0.5)


def set_state():
    global state
    # state variable has been defined outside
    if state < 3:
        state += 1
    elif state == 3:
        state = 0
    else:
        pass


def button_event(event):
    global state
    if event.action == "released":
        if state != 4:
            state = 4
        else:
            state = 3


def halt_unleash_event(event):
    global halted
    if event.action == "released":
        halted = not halted
        if halted:
            print("Halted")
        else:
            print("Unleash")


sense.stick.direction_middle = button_event
sense.stick.direction_up = halt_unleash_event


def main():
    global state, halted
    while True:
        if halted:
            time.sleep(0.1)
            continue

        if state == 0:
            states(3)
        elif state == 1:
            states(1)
        elif state == 2:
            states(2)
        elif state == 3:
            states(1)
        else:
            out_of_order_state()
        set_state()


if __name__ == "__main__":
    main()
